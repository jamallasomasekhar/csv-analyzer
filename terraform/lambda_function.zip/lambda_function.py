import json
import boto3
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info('Starting S3 bucket analysis')
          
    try:
        # Create S3 client
        s3_client = boto3.client('s3')
              
        # List all buckets
        response = s3_client.list_buckets()
        buckets = [bucket['Name'] for bucket in response['Buckets']]
        logger.info(f'Found {len(buckets)} S3 buckets: {buckets}')
              
        # Get bucket from event or use default
        target_bucket = event.get('bucket_name') if event else None
              
        if not target_bucket and len(buckets) > 0:
            target_bucket = buckets[0]
            logger.info(f'No bucket specified, using first bucket: {target_bucket}')
              
        bucket_stats = None
        if target_bucket:
            # Count objects in the specified bucket
            paginator = s3_client.get_paginator('list_objects_v2')
            total_objects = 0
            total_size = 0
                  
            for page in paginator.paginate(Bucket=target_bucket):
                if 'Contents' in page:
                    total_objects += len(page['Contents'])
                    total_size += sum(obj['Size'] for obj in page['Contents'])
                  
            bucket_stats = {
                "name": target_bucket,
                "object_count": total_objects,
                "total_size_bytes": total_size,
                "total_size_mb": round(total_size / (1024 * 1024), 2)
            }
                  
            logger.info(f'Bucket stats for {target_bucket}: {bucket_stats}')
              
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'S3 analysis completed successfully',
                'bucket_count': len(buckets),
                'buckets': buckets,
                'selected_bucket_stats': bucket_stats
            })
        }
              
    except Exception as e:
        error_message = str(e)
        logger.error(f'Error analyzing S3 buckets: {error_message}')
              
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Error analyzing S3 buckets',
                'error': error_message
            })
        }
